/* Source file for abstract network class  */



/* Include files */

#include "RNNets/RNNets.h"



// Namespace

namespace gaps {



RNNetwork::
RNNetwork()
{
}

 


RNNetwork::
~RNNetwork()
{
} 

 

} // namespace gaps
