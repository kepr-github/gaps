extern int ReadNumpyFile(const char *filename, 
  int *data_type = NULL, int *data_size = NULL, int *fortran_order = NULL,
  int *returned_width = NULL, int *returned_height = NULL, int *returned_depth = NULL,
  unsigned char **returned_array = NULL);
